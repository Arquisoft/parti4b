var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "6045",
        "ok": "4498",
        "ko": "1547"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "59712",
        "ok": "59712",
        "ko": "2148"
    },
    "meanResponseTime": {
        "total": "5943",
        "ok": "7986",
        "ko": "4"
    },
    "standardDeviation": {
        "total": "11294",
        "ok": "12455",
        "ko": "87"
    },
    "percentiles1": {
        "total": "567",
        "ok": "1373",
        "ko": "0"
    },
    "percentiles2": {
        "total": "7612",
        "ok": "9151",
        "ko": "0"
    },
    "percentiles3": {
        "total": "37130",
        "ok": "41303",
        "ko": "0"
    },
    "percentiles4": {
        "total": "47747",
        "ok": "51271",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1789,
        "percentage": 30
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 317,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2392,
        "percentage": 40
    },
    "group4": {
        "name": "failed",
        "count": 1547,
        "percentage": 26
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "17.779",
        "ok": "13.229",
        "ko": "4.55"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1356",
        "ok": "1356",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "703",
        "ok": "703",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "300",
        "ok": "300",
        "ko": "-"
    },
    "percentiles1": {
        "total": "758",
        "ok": "758",
        "ko": "-"
    },
    "percentiles2": {
        "total": "934",
        "ok": "934",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1168",
        "ok": "1168",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1243",
        "ok": "1243",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 273,
        "percentage": 55
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 216,
        "percentage": 43
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 11,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.471",
        "ko": "-"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "545",
        "ok": "500",
        "ko": "45"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "200",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "20394",
        "ok": "20394",
        "ko": "2148"
    },
    "meanResponseTime": {
        "total": "6353",
        "ok": "6913",
        "ko": "132"
    },
    "standardDeviation": {
        "total": "3475",
        "ok": "3057",
        "ko": "495"
    },
    "percentiles1": {
        "total": "6932",
        "ok": "7367",
        "ko": "0"
    },
    "percentiles2": {
        "total": "8919",
        "ok": "9063",
        "ko": "0"
    },
    "percentiles3": {
        "total": "10525",
        "ok": "10639",
        "ko": "1507"
    },
    "percentiles4": {
        "total": "12945",
        "ok": "13117",
        "ko": "2045"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 17,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 481,
        "percentage": 88
    },
    "group4": {
        "name": "failed",
        "count": 45,
        "percentage": 8
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.603",
        "ok": "1.471",
        "ko": "0.132"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "283",
        "ok": "283",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "12221",
        "ok": "12221",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2125",
        "ok": "2125",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1895",
        "ok": "1895",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1354",
        "ok": "1354",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3101",
        "ok": "3101",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6111",
        "ok": "6111",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9836",
        "ok": "9836",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 92,
        "percentage": 18
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 56,
        "percentage": 11
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 352,
        "percentage": 70
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.471",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "500",
        "ok": "456",
        "ko": "44"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "251",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "45366",
        "ok": "45366",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "2865",
        "ok": "3142",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "3876",
        "ok": "3951",
        "ko": "0"
    },
    "percentiles1": {
        "total": "971",
        "ok": "1927",
        "ko": "0"
    },
    "percentiles2": {
        "total": "3261",
        "ok": "4105",
        "ko": "0"
    },
    "percentiles3": {
        "total": "10033",
        "ok": "10053",
        "ko": "0"
    },
    "percentiles4": {
        "total": "13214",
        "ok": "13537",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 184,
        "percentage": 37
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 28,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 244,
        "percentage": 49
    },
    "group4": {
        "name": "failed",
        "count": 44,
        "percentage": 9
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.341",
        "ko": "0.129"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "500",
        "ok": "424",
        "ko": "76"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "5376",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "59712",
        "ok": "59712",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "18190",
        "ok": "21451",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "14977",
        "ok": "13949",
        "ko": "0"
    },
    "percentiles1": {
        "total": "15099",
        "ok": "17428",
        "ko": "0"
    },
    "percentiles2": {
        "total": "23979",
        "ok": "28668",
        "ko": "0"
    },
    "percentiles3": {
        "total": "48401",
        "ok": "49388",
        "ko": "0"
    },
    "percentiles4": {
        "total": "55782",
        "ok": "56461",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 424,
        "percentage": 85
    },
    "group4": {
        "name": "failed",
        "count": 76,
        "percentage": 15
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.247",
        "ko": "0.224"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "500",
        "ok": "28",
        "ko": "472"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "51270",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "59406",
        "ok": "59406",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "3118",
        "ok": "55687",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "12814",
        "ok": "2117",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "55900",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "57272",
        "ko": "0"
    },
    "percentiles3": {
        "total": "51552",
        "ok": "58326",
        "ko": "0"
    },
    "percentiles4": {
        "total": "57564",
        "ok": "59128",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 28,
        "percentage": 6
    },
    "group4": {
        "name": "failed",
        "count": 472,
        "percentage": 94
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "0.082",
        "ko": "1.388"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "500",
        "ok": "44",
        "ko": "456"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "31052",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "31890",
        "ok": "31890",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "2769",
        "ok": "31463",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "8913",
        "ok": "166",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "31473",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "31554",
        "ko": "0"
    },
    "percentiles3": {
        "total": "31459",
        "ok": "31714",
        "ko": "0"
    },
    "percentiles4": {
        "total": "31620",
        "ok": "31832",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 44,
        "percentage": 9
    },
    "group4": {
        "name": "failed",
        "count": 456,
        "percentage": 91
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "0.129",
        "ko": "1.341"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "500",
        "ok": "46",
        "ko": "454"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1298",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "54388",
        "ok": "54388",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "819",
        "ok": "8905",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "3472",
        "ok": "7683",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "7795",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "8250",
        "ko": "0"
    },
    "percentiles3": {
        "total": "7675",
        "ok": "8881",
        "ko": "0"
    },
    "percentiles4": {
        "total": "8593",
        "ok": "43655",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 46,
        "percentage": 9
    },
    "group4": {
        "name": "failed",
        "count": 454,
        "percentage": 91
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "0.135",
        "ko": "1.335"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "49955",
        "ok": "49955",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "26193",
        "ok": "26193",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "16686",
        "ok": "16686",
        "ko": "-"
    },
    "percentiles1": {
        "total": "32543",
        "ok": "32543",
        "ko": "-"
    },
    "percentiles2": {
        "total": "41688",
        "ok": "41688",
        "ko": "-"
    },
    "percentiles3": {
        "total": "45574",
        "ok": "45574",
        "ko": "-"
    },
    "percentiles4": {
        "total": "46988",
        "ok": "46988",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 91,
        "percentage": 18
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 409,
        "percentage": 82
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.471",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16590",
        "ok": "16590",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7219",
        "ok": "7219",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5421",
        "ok": "5421",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9080",
        "ok": "9080",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9898",
        "ok": "9898",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15377",
        "ok": "15377",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15635",
        "ok": "15635",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 163,
        "percentage": 33
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 337,
        "percentage": 67
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.471",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "15405",
        "ok": "15405",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "681",
        "ok": "681",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2086",
        "ok": "2086",
        "ko": "-"
    },
    "percentiles1": {
        "total": "349",
        "ok": "349",
        "ko": "-"
    },
    "percentiles2": {
        "total": "566",
        "ok": "566",
        "ko": "-"
    },
    "percentiles3": {
        "total": "613",
        "ok": "613",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14465",
        "ok": "14465",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 486,
        "percentage": 97
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 14,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.471",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "500",
        "ok": "500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9898",
        "ok": "9898",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "602",
        "ok": "602",
        "ko": "-"
    },
    "percentiles1": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "percentiles2": {
        "total": "288",
        "ok": "288",
        "ko": "-"
    },
    "percentiles3": {
        "total": "379",
        "ok": "379",
        "ko": "-"
    },
    "percentiles4": {
        "total": "584",
        "ok": "584",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 498,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.471",
        "ok": "1.471",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
