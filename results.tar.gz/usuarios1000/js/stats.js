var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "12052",
        "ok": "4260",
        "ko": "7792"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "59506",
        "ok": "59506",
        "ko": "10680"
    },
    "meanResponseTime": {
        "total": "3143",
        "ok": "8863",
        "ko": "15"
    },
    "standardDeviation": {
        "total": "7448",
        "ok": "10300",
        "ko": "342"
    },
    "percentiles1": {
        "total": "0",
        "ok": "6002",
        "ko": "0"
    },
    "percentiles2": {
        "total": "1463",
        "ok": "12521",
        "ko": "0"
    },
    "percentiles3": {
        "total": "16673",
        "ok": "26834",
        "ko": "0"
    },
    "percentiles4": {
        "total": "42013",
        "ok": "53853",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 725,
        "percentage": 6
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 389,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3146,
        "percentage": 26
    },
    "group4": {
        "name": "failed",
        "count": 7792,
        "percentage": 65
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "21.993",
        "ok": "7.774",
        "ko": "14.219"
    }
},
contents: {
"req_request-0-684d2": {
        type: "REQUEST",
        name: "request_0",
path: "request_0",
pathFormatted: "req_request-0-684d2",
stats: {
    "name": "request_0",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1411",
        "ok": "1411",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "703",
        "ok": "703",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "269",
        "ok": "269",
        "ko": "-"
    },
    "percentiles1": {
        "total": "732",
        "ok": "731",
        "ko": "-"
    },
    "percentiles2": {
        "total": "883",
        "ok": "883",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1112",
        "ok": "1112",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1316",
        "ok": "1316",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 631,
        "percentage": 63
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 345,
        "percentage": 35
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 24,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "1.825",
        "ko": "-"
    }
}
    },"req_bootstrap-min-c-5b8a7": {
        type: "REQUEST",
        name: "bootstrap.min.css",
path: "bootstrap.min.css",
pathFormatted: "req_bootstrap-min-c-5b8a7",
stats: {
    "name": "bootstrap.min.css",
    "numberOfRequests": {
        "total": "1052",
        "ok": "883",
        "ko": "169"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "691",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "51414",
        "ok": "51414",
        "ko": "10680"
    },
    "meanResponseTime": {
        "total": "10806",
        "ok": "12738",
        "ko": "711"
    },
    "standardDeviation": {
        "total": "7376",
        "ok": "6375",
        "ko": "2212"
    },
    "percentiles1": {
        "total": "12135",
        "ok": "13676",
        "ko": "0"
    },
    "percentiles2": {
        "total": "15768",
        "ok": "16503",
        "ko": "0"
    },
    "percentiles3": {
        "total": "20587",
        "ok": "21717",
        "ko": "6337"
    },
    "percentiles4": {
        "total": "27129",
        "ok": "27447",
        "ko": "10563"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 3,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 22,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 858,
        "percentage": 82
    },
    "group4": {
        "name": "failed",
        "count": 169,
        "percentage": 16
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.92",
        "ok": "1.611",
        "ko": "0.308"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "150",
        "ok": "150",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17893",
        "ok": "17893",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2997",
        "ok": "2997",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2874",
        "ok": "2874",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5174",
        "ok": "5174",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9496",
        "ok": "9496",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15581",
        "ok": "15581",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 74,
        "percentage": 7
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 22,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 904,
        "percentage": 90
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "1.825",
        "ko": "-"
    }
}
    },"req_request-2-93baf": {
        type: "REQUEST",
        name: "request_2",
path: "request_2",
pathFormatted: "req_request-2-93baf",
stats: {
    "name": "request_2",
    "numberOfRequests": {
        "total": "1000",
        "ok": "834",
        "ko": "166"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2884",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "58099",
        "ok": "58099",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "7880",
        "ok": "9449",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "5229",
        "ok": "4238",
        "ko": "0"
    },
    "percentiles1": {
        "total": "9424",
        "ok": "9579",
        "ko": "0"
    },
    "percentiles2": {
        "total": "10811",
        "ok": "11188",
        "ko": "0"
    },
    "percentiles3": {
        "total": "12525",
        "ok": "12567",
        "ko": "0"
    },
    "percentiles4": {
        "total": "19010",
        "ok": "19331",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 834,
        "percentage": 83
    },
    "group4": {
        "name": "failed",
        "count": 166,
        "percentage": 17
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "1.522",
        "ko": "0.303"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "1000",
        "ok": "477",
        "ko": "523"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "11048",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "59411",
        "ok": "59411",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "11785",
        "ok": "24706",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "15130",
        "ok": "12677",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "19375",
        "ko": "0"
    },
    "percentiles2": {
        "total": "19139",
        "ok": "30885",
        "ko": "0"
    },
    "percentiles3": {
        "total": "45478",
        "ok": "52260",
        "ko": "0"
    },
    "percentiles4": {
        "total": "55689",
        "ok": "58065",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 477,
        "percentage": 48
    },
    "group4": {
        "name": "failed",
        "count": 523,
        "percentage": 52
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "0.87",
        "ko": "0.954"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "1000",
        "ok": "9",
        "ko": "991"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "50913",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "59506",
        "ok": "59506",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "503",
        "ok": "55895",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "5284",
        "ok": "2541",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "56572",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "57362",
        "ko": "0"
    },
    "percentiles3": {
        "total": "0",
        "ok": "59262",
        "ko": "0"
    },
    "percentiles4": {
        "total": "30650",
        "ok": "59457",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 9,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 991,
        "percentage": 99
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "0.016",
        "ko": "1.808"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "1000",
        "ok": "0",
        "ko": "1000"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles3": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles4": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1000,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "-",
        "ko": "1.825"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "1000",
        "ok": "0",
        "ko": "1000"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles3": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles4": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1000,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "-",
        "ko": "1.825"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "1000",
        "ok": "0",
        "ko": "1000"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles3": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles4": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1000,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "-",
        "ko": "1.825"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "1000",
        "ok": "0",
        "ko": "1000"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles3": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles4": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1000,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "-",
        "ko": "1.825"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "1000",
        "ok": "17",
        "ko": "983"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "54378",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "58019",
        "ok": "58019",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "950",
        "ok": "55899",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "7228",
        "ok": "1255",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "56397",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "56751",
        "ko": "0"
    },
    "percentiles3": {
        "total": "0",
        "ok": "58019",
        "ko": "0"
    },
    "percentiles4": {
        "total": "54936",
        "ok": "58019",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 17,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 983,
        "percentage": 98
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "0.031",
        "ko": "1.794"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "1000",
        "ok": "40",
        "ko": "960"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "47967",
        "ok": "47967",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "1016",
        "ok": "25394",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "6695",
        "ok": "22395",
        "ko": "0"
    },
    "percentiles1": {
        "total": "0",
        "ok": "36003",
        "ko": "0"
    },
    "percentiles2": {
        "total": "0",
        "ok": "46682",
        "ko": "0"
    },
    "percentiles3": {
        "total": "0",
        "ok": "47516",
        "ko": "0"
    },
    "percentiles4": {
        "total": "46517",
        "ok": "47959",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 17,
        "percentage": 2
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 23,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 960,
        "percentage": 96
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.825",
        "ok": "0.073",
        "ko": "1.752"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
